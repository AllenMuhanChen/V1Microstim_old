INSERT INTO SystemVar VALUES ('xper_first_slide_length',0,1097009302111741,'5000');
INSERT INTO SystemVar VALUES ('xper_first_inter_slide_interval',0,1097009302112036,'5000');

INSERT INTO SystemVar VALUES ('xper_blank_target_screen_display_time',0,1097009302112036,'5000');

INSERT INTO SystemVar VALUES ('xper_early_target_fixation_allowable_time',0,1406685423362303,'-1');