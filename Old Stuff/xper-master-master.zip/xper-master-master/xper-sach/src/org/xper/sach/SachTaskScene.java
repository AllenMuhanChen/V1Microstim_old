package org.xper.sach;


import org.xper.drawing.Context;

public interface SachTaskScene {

	public void drawTargetScene(Context context);

}