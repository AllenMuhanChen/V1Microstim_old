package org.xper.match;

import org.xper.drawing.Context;

public interface MatchTaskScene {

	public void drawTarget(Context context);

}