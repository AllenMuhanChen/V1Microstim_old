package org.xper.console;

public interface MessageReceiverEventListener {
	public void messageReceived ();
}
