package org.xper.drawing;

public class Coordinates2D {
	double x;
	double y;
	
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public Coordinates2D(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}
	public Coordinates2D() {	
	}
}
