package org.xper.drawing;


public interface ScreenMarker extends Drawable {
	public void next ();
	public void drawAllOff(Context context);
}
