package org.xper.drawing;

import org.xper.experiment.ExperimentTask;

public class BlankTaskScene extends AbstractTaskScene {

	public void drawStimulus(Context context) {
	}

	public void setTask(ExperimentTask task) {
	}

}
