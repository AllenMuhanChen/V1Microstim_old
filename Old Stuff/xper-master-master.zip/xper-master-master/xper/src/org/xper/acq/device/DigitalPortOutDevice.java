package org.xper.acq.device;


public interface DigitalPortOutDevice {

	public abstract void write(long[] data);

}