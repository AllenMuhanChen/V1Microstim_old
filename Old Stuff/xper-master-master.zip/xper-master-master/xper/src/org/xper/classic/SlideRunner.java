package org.xper.classic;

import org.xper.classic.vo.TrialResult;


public interface SlideRunner {
	public TrialResult runSlide();
}
