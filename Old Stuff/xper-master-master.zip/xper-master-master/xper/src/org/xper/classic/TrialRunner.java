package org.xper.classic;

import org.xper.classic.vo.TrialResult;



public interface TrialRunner {
	public TrialResult runTrial();
}
