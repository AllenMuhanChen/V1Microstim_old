package org.xper.juice.mock;

import org.xper.juice.DynamicJuice;

public class NullDynamicJuice implements DynamicJuice {

	public void setReward(double reward) {
	}

	public void deliver() {
	}

}
