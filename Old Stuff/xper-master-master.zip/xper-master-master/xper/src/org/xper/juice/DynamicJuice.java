package org.xper.juice;

public interface DynamicJuice extends Juice {
	public void setReward(double reward);
}
