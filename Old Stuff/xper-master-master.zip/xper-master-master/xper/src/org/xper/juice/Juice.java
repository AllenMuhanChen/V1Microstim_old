package org.xper.juice;

public interface Juice {
	public void deliver();
}
