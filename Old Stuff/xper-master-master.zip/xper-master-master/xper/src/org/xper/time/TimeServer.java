package org.xper.time;

import org.xper.experiment.Threadable;

public interface TimeServer extends Threadable {
	public int getPort();
}
