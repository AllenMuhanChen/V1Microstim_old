package org.xper.time;

public interface TimeUtil {
	public long currentTimeMicros ();
}
