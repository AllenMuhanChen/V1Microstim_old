package org.xper.experiment;

public interface Stoppable {
	public void stop();
}
