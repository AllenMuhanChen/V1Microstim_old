package org.xper.experiment.listener;

import org.xper.experiment.Threadable;

public interface MessageDispatcher extends Threadable{
}
