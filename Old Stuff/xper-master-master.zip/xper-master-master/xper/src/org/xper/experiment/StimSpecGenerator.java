package org.xper.experiment;

public interface StimSpecGenerator {
	public String generateStimSpec();
}
