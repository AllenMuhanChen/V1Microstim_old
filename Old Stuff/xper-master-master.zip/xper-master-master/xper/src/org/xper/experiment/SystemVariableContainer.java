package org.xper.experiment;

public interface SystemVariableContainer {
	public String get(String name, int index);
	public void refresh();
}
