package org.xper.experiment;

public interface Experiment extends Threadable {

	public void setPause(boolean pause);
}
