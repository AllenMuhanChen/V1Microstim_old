package org.xper.choice;

import org.xper.drawing.Context;

public interface ChoiceTaskScene {

	public void drawAllTargets(Context context);
	public void drawSelectedTarget(Context context, int sel);

}