package org.xper.drawing;

public interface DrawableFactory {
	public Drawable getDrawable(boolean solid, double size);
}
